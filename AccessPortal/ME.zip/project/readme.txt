Packages to be downloaded:

pip install Flask
pip install Flask-SQLAlchemy
pip install Flask-Login
pip install mysqlclient  # or alternatively: pip install PyMySQL
pip install debugpy

Softwares to be downloaded:
xampp server download

Run main7.py 